from time import sleep
from playsound import playsound
playsound("A.wav")
sleep(1)